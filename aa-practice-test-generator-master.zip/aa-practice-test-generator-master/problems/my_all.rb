class Array

  def my_all?(&prc)

  end

end
