class Array

  def my_select(&prc)

  end

end
