class Array

  def my_any?(&prc)

  end

end
