class Array

  def my_join(str = "")

  end

end
