class Timer
  # TODO: your code goes here!
end 