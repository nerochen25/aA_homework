class MyHashSet
  # TODO: your code goes here!
end