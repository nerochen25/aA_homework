class Temperature
  # TODO: your code goes here!

end

# Subclasses/Inheritance
class Celsius < Temperature

end 

class Fahrenheit < Temperature

end