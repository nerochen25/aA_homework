class RPNCalculator
  # TODO: your code goes here!
end
