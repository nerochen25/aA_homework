class Array
  # Write an Array method that returns a bubble-sorted copy of an array. 
  # Do NOT call the built-in Array#sort method in your implementation. 
  def bubble_sort(&prc)
  end

  # You are not required to implement this; it's here as a suggestion :-)
  def bubble_sort!(&prc)
  end
end

class Array
  # Write an array method that returns a hash where the keys are any element
  # that appears in the array more than once, and the values are sorted arrays
  # of indices for those elements.
  def dups
  end
end



# Write a method that finds the first `n` Fibonacci numbers recursively.
def fibs_rec(count)
end

class String
  # Write a method that finds all the unique substrings for a word

  def uniq_subs
  end
end

def is_prime?(num)
end

# Write a method that returns the nth prime number
def nth_prime(n)
end

class Array
  # Write a method that calls a passed block for each element of the array
  def my_each(&prc)
  end
end

class Array
  # Write a method that calls a block for each element of the array
  # and returns a new array made up of the results
  def my_map(&prc)
  end
end

